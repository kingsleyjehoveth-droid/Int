package com.example.instagramclone.data

import com.example.instagramclone.model.Post
import com.example.instagramclone.model.Story

object DataSource {
    val stories = listOf(
        Story(1, "tu_usuario", "https://via.placeholder.com/150"),
        Story(2, "android_dev", "https://via.placeholder.com/150")
    )

    val posts = listOf(
        Post(1, "android_dev", "https://via.placeholder.com/150", "https://via.placeholder.com/400", 120, "¡Mi primer post en Compose!"),
        Post(2, "kotlin_fan", "https://via.placeholder.com/150", "https://via.placeholder.com/400", 85, "Organizar paquetes es clave.")
    )
}