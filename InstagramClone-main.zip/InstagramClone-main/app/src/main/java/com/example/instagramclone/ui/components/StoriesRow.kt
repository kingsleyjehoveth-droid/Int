package com.example.instagramclone.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.instagramclone.model.Story

@Composable
fun StoriesRow(stories: List<Story>) {
    // TODO: usar LazyRow para scroll horizontal
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp) // TODO: espacio entre items
    ) {
        items(stories) { story ->
            StoryItem(story = story)
        }
    }
}

@Composable
fun StoryItem(story: Story) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(78.dp)
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .padding(3.dp),
            contentAlignment = Alignment.Center
        ) {
            // El círculo gris que representa la foto
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape),
                color = Color.LightGray
            ) { }
        }
        // El nombre del usuario debajo del círculo
        Text(
            text = story.username,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
        )
    }
}