package com.example.instagramclone.model

// La palabra clave es 'data' para que sea una clase de datos
data class Post(
    val id: Int,
    val username: String,
    val profileImageUrl: String, // Propiedad que faltaba
    val imageUrl: String,
    val likes: Int,
    val caption: String,
    val isLiked: Boolean = false // Tipo Boolean con valor por defecto
)