package com.example.instagramclone.ui.components


import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.instagramclone.model.Post

@Composable
fun PostCard(post: Post) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        // Nombre de usuario
        Text(text = post.username)

        // Espacio para la imagen (se agregará más adelante)
        Spacer(modifier = Modifier.height(200.dp))

        // Descripción
        Text(text = post.caption)
    }
}