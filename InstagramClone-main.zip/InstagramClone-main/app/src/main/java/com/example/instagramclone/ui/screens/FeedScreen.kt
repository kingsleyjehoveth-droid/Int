package com.example.instagramclone.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.instagramclone.data.DataSource
import com.example.instagramclone.ui.components.PostCard
import com.example.instagramclone.ui.components.StoriesRow

@Composable
fun FeedScreen() {
    // Usamos LazyColumn para que toda la pantalla tenga scroll vertical
    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {
        // PASO 1: Agregar la fila de historias (scroll horizontal)
        item {
            StoriesRow(stories = DataSource.stories)
        }

        // PASO 2: Agregar la lista de publicaciones
        items(
            items = DataSource.posts,
            key = { post -> post.id } // La 'key' ayuda a que la lista sea fluida
        ) { post ->
            PostCard(post = post)
        }
    }
}